Install npm 
Ejecutar npm run dev